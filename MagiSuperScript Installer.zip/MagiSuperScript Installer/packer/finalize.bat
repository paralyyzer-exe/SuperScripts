@echo off
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [ERROR] This script must be run as Administrator.
    pause
    exit /b
)

pushd "%~dp0.."
set "RootDir=%cd%"
popd

set "TargetPath=%RootDir%\main.exe"
set "ShortcutPath=%ProgramData%\Microsoft\Windows\Start Menu\Programs\Startup\MyProgram.lnk"

if not exist "%TargetPath%" (
    echo [ERROR] Could not find main.exe at: %TargetPath%
    pause
    exit /b
)

echo Set oWS = WScript.CreateObject("WScript.Shell") > "%TEMP%\CreateShortcut.vbs"
echo sLinkFile = "%ShortcutPath%" >> "%TEMP%\CreateShortcut.vbs"
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> "%TEMP%\CreateShortcut.vbs"
echo oLink.TargetPath = "%TargetPath%" >> "%TEMP%\CreateShortcut.vbs"
echo oLink.WorkingDirectory = "%RootDir%" >> "%TEMP%\CreateShortcut.vbs"
echo oLink.Save >> "%TEMP%\CreateShortcut.vbs"

cscript //nologo "%TEMP%\CreateShortcut.vbs"
del "%TEMP%\CreateShortcut.vbs"

echo Success! All-user startup shortcut linked to %TargetPath%
